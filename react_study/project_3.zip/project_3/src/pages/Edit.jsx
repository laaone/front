import {useParams,useNavigate} from "react-router-dom";
import useDiary from "../hooks/useDiary";
import Button from "../component/Button";
import Header from "../component/Header";
import { useContext, useEffect } from "react";
import { DiaryDispatchContext } from "../App";
import Editor from "../component/Editor";
import { setPageTitle } from "../util";


const Edit = ()=>{
    const { id } = useParams();
    const data = useDiary(id);
    const navigate = useNavigate();
    const { upDelete, onUpdate } =  useContext( DiaryDispatchContext );
     useEffect( ()=> setPageTitle(`${id}번 일기 수정하기`) ,[]);


    const onClickDelete = ()=>{
        if(window.confirm("일기를 정말 삭제할까요? 다시 복구되지 않아요!")){
            upDelete(id);
            navigate("/", {replace:true});
        }
    };
    const onSubmit = (data) => {
        if(window.confirm("일기를 정말 수정할까요?")){
            const {date, content,emotionId} = data;
            onUpdate( id,date, content, emotionId );
            navigate("/", {replact:true});
        }
    }
       
    
    const goBack = ()=>{
        navigate(-1);
    }
    if( !data ) {
        return <div> 일기를 불러오고 있습니다...</div>
    }else{
    return(
            <>
              <Header 
                      title={"일기 수정하기"}
                      leftChild={ <Button text={"< 뒤로 가기"} onClick={goBack} />}
                      rightChild={ <Button type={"negative"} text={"삭제하기"} 
                                    onClick={onClickDelete} 
                       />}
               />
               <Editor initData={data} onSubmit={onSubmit} />
            </>
        );
    }

}
export default Edit;