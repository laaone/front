import "./Viewer.css";
import { emotionList } from "../util";

const Viewer = ({content, emotionId})=> {

    const emotionItem = emotionList.find( (it)=> String(it.id) === String(emotionId));
    if (!emotionItem) {
        return <div className="Viewer">잘못된 데이터입니다.</div>;
    }

    return(
    <div className="Viewer">
        <section>
            <h4> 오늘의 감정 </h4>
            <div className={`emotionItem_img_wrapper emotion_img_wrapper_${emotionId}` } >
               <img  alt={emotionItem.name} src={emotionItem.img} />
                <div className="emotion_descript"> {emotionItem.name} </div>
             </div>
        </section>
           <section>
            <h4> 오늘의 일기 </h4>
            <div className="content_wrapper">
                <p> {content} </p>
            </div>
           </section>
        </div>
    )
}
export default Viewer;











